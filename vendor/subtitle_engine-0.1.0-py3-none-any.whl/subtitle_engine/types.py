"""Provider-neutral, integer-millisecond cues and revision-ready events."""
from dataclasses import dataclass
from typing import Literal


@dataclass(frozen=True)
class Segment:
    id: str
    start_ms: int
    end_ms: int
    text: str

    def __post_init__(self):
        if (type(self.start_ms) is not int or type(self.end_ms) is not int
                or self.start_ms < 0 or self.end_ms <= self.start_ms):
            raise ValueError("Segment requires nonnegative start and positive duration")
        if not isinstance(self.id, str) or not self.id.strip():
            raise ValueError("Segment requires an ID")
        if not isinstance(self.text, str) or not self.text.strip():
            raise ValueError("Segment requires text")


@dataclass(frozen=True)
class SegmentEvent:
    stage: Literal["transcription", "correction", "translation"]
    segment: Segment
    revision: int = 0
    final: bool = True


def to_srt(segments):
    def timestamp(ms):
        seconds, millis = divmod(ms, 1000)
        minutes, seconds = divmod(seconds, 60)
        hours, minutes = divmod(minutes, 60)
        return f"{hours:02}:{minutes:02}:{seconds:02},{millis:03}"
    validate_segments(segments)
    return "\n\n".join(
        f"{i}\n{timestamp(s.start_ms)} --> {timestamp(s.end_ms)}\n{s.text}"
        for i, s in enumerate(segments, 1)
    ) + "\n"


def validate_segments(segments):
    if not segments or len({s.id for s in segments}) != len(segments):
        raise ValueError("Nonempty segments with unique IDs required")
    if any(a.start_ms > b.start_ms for a, b in zip(segments, segments[1:])):
        raise ValueError("Segments must be ordered; overlapping intervals are allowed")


def from_srt(content, ids=None):
    from .processor import VideoSubtitleProcessor
    def milliseconds(timestamp):
        h, m, s = timestamp.replace(',', '.').split(':')
        sec, ms = s.split('.')
        return int(h)*3600000 + int(m)*60000 + int(sec)*1000 + int(ms)
    result = []
    for i, lines in enumerate(VideoSubtitleProcessor._srt_entries(content)):
        start, end = lines[1].split(' --> ')
        result.append(Segment(ids[i] if ids is not None else lines[0],
                              milliseconds(start), milliseconds(end), '\n'.join(lines[2:])))
    validate_segments(result)
    return tuple(result)
