"""Batch Python API. Segment events are completed-stage events, not live ASR.

Custom ASR providers implement transcribe(audio, model, language) -> segments.
Text providers implement transform(segments, context, target_language) -> segments.
Credentials belong in provider instances/environment, never serialized job options.
"""
from dataclasses import dataclass, field
from pathlib import Path
from typing import Protocol, Sequence

from .types import Segment, SegmentEvent, from_srt, to_srt, validate_segments


class ASRProvider(Protocol):
    def transcribe(self, audio: Path, *, model: str, language: str) -> Sequence[Segment]: ...


class TextProvider(Protocol):
    def transform(self, segments: Sequence[Segment], *, context: str,
                  target_language: str | None) -> Sequence[Segment]: ...


@dataclass(frozen=True)
class ASRSelection:
    provider: str = "whisper"
    model: str = "base"


@dataclass(frozen=True)
class TextSelection:
    provider: str = "local-runtime"
    model: str | None = None


@dataclass(frozen=True)
class PipelineConfig:
    asr: ASRSelection = field(default_factory=ASRSelection)
    correction: TextSelection | None = field(default_factory=TextSelection)
    translation: TextSelection | None = field(default_factory=TextSelection)
    source_language: str = "auto"
    target_language: str | None = "zh-TW"
    context: str = ""
    max_workers: int = 2

    @classmethod
    def from_legacy(cls, options):
        from .worker import validate_options
        options = validate_options(options)
        text = TextSelection(options['provider'], options['model'])
        return cls(ASRSelection('whisper', options['whisper_model']),
                   None if options['skip_correction'] else text,
                   text if options['target_language'] else None,
                   options['source_language'], options['target_language'],
                   options['context'], options['max_workers'])


class WhisperASR:
    """Local, batch Whisper API; no claims of streaming or latency guarantees."""
    def transcribe(self, audio, *, model, language):
        import whisper
        result = whisper.load_model(model).transcribe(
            str(audio), language=None if language == 'auto' else language)
        return tuple(Segment(str(i), round(cue['start'] * 1000), round(cue['end'] * 1000),
                             cue['text'].strip()) for i, cue in enumerate(result['segments'], 1))


class LLMTextProvider:
    def __init__(self, selection, config):
        from .worker import DEFAULTS, processor_for
        self.processor = processor_for(DEFAULTS | dict(
            provider=selection.provider, model=selection.model,
            source_language=config.source_language, max_workers=config.max_workers))
        if not (self.processor.client or self.processor.openai_client):
            raise ValueError("Missing provider credentials")

    def transform(self, segments, *, context, target_language):
        source = to_srt(segments)
        result = self.processor.correct_subtitle_with_llm(
            source, context=context, target_language=target_language)
        self.processor._validate_subtitle_alignment(source, result)
        return from_srt(result, [s.id for s in segments])


class Pipeline:
    def __init__(self, config=None, *, asr_providers=None, text_factory=None):
        self.config = config or PipelineConfig()
        self.asr_providers = {'whisper': WhisperASR()} | (asr_providers or {})
        self.text_factory = text_factory or LLMTextProvider

    def run(self, *, audio=None, segments=None, emit=None):
        if (audio is None) == (segments is None):
            raise ValueError("Provide exactly one of audio or imported segments")
        config = self.config
        if segments is None:
            provider = self.asr_providers[config.asr.provider]
            segments = provider.transcribe(Path(audio), model=config.asr.model,
                                           language=config.source_language)
        current = tuple(segments)
        validate_segments(current)
        def publish(stage):
            if emit:
                for segment in current:
                    emit(SegmentEvent(stage, segment))
        publish('transcription')
        for stage, selection, target in (
            ('correction', config.correction, None),
            ('translation', config.translation if config.target_language else None, config.target_language),
        ):
            if selection is None:
                continue
            provider = self.text_factory(selection, config)
            result = tuple(provider.transform(current, context=config.context, target_language=target))
            validate_segments(result)
            if [(s.id, s.start_ms, s.end_ms) for s in result] != [
                    (s.id, s.start_ms, s.end_ms) for s in current]:
                raise ValueError("Text provider changed segment identity or timestamps")
            current = result
            publish(stage)
        return current
