"""Vision-LLM judgement: which on-screen text to translate, corrected source text and translation."""
import base64
import io
import json
import os
import re
import sys
import time
from concurrent.futures import ThreadPoolExecutor
from pathlib import Path

from .track import has_letters, key_frame, similarity

KINDS = {"speech_caption", "comment_caption", "title_card", "logo", "clothing_or_prop", "background_sign", "other"}
TRANSLATABLE = {"speech_caption", "comment_caption", "title_card"}
LANGUAGE_NAMES = {
    "zh-TW": "Traditional Chinese as used in Taiwan (繁體中文，台灣用語)",
    "zh-CN": "Simplified Chinese", "en": "English", "ja": "Japanese", "ko": "Korean",
}


class JudgeOutputError(ValueError):
    """Model output did not cover exactly the requested ids; the group is retried or split."""


def make_client(provider="local-runtime", model=None):
    from openai import OpenAI
    if provider == "local-runtime":
        root = Path.home() / "Library/Application Support/personal-ai-runtime"
        config = json.loads((root / "connection.json").read_text(encoding="utf-8"))
        client = OpenAI(api_key=config["api_key"], base_url=config["base_url"],
                        default_headers=config.get("headers") or None)
        return client, model or config.get("model", "gpt-6-luna")
    if provider == "openai":
        key = os.environ.get("OPENAI_API_KEY")
        if not key:
            raise ValueError("需要 OPENAI_API_KEY")
        return OpenAI(api_key=key, base_url=os.environ.get("OPENAI_BASE_URL") or None), model or "gpt-4o"
    raise ValueError(f"畫面字幕判讀不支援 provider: {provider}")


PROMPT = """You help a fansub team translate post-production on-screen captions (Korean variety-show style 編輯字幕) into {language}. The translation will be drawn exactly where the original text is, so you must decide per text item whether it should be replaced.

The image is one video frame ({w}x{h}). Each OCR-detected text item is outlined with a red box and labelled with its id. Some items may be visible only shortly before or after this frame; use the OCR text for those.
{items}

Dialogue spoken around this moment (already translated; use for context and consistent names, do not copy blindly):
{dialogue}
{context}
Return a JSON array with exactly one object per id above, fields:
- "id": the id
- "kind": "speech_caption" (transcribes what someone says), "comment_caption" (editor narration, joke, reaction or sound effect added in post), "title_card" (segment title / heading / name tag added in post), "logo" (show or brand logo, watermark), "clothing_or_prop" (text printed on clothes, cups, paper, objects), "background_sign" (signage or text physically in the scene), "other"
- "translate": true only for speech_caption, comment_caption, title_card that a viewer of the translation needs; false for everything else
- "source": the original text, correcting only clear OCR misreads you can verify in the image; if it is only symbols or punctuation keep it exactly
- "translation": concise natural fansub translation in {language}; keep the tone and emphasis; render bracket headings like [ ] as 【 】; no trailing 。; null when translate is false
Only return the JSON array, no markdown."""


def dialogue_window(dialogue, start, end, margin=4.0):
    return [text for s, e, text in dialogue if e >= start - margin and s <= end + margin]


def annotated_jpeg(frame_path, group):
    from PIL import Image, ImageDraw
    img = Image.open(frame_path).convert("RGB")
    draw = ImageDraw.Draw(img)
    for e in group:
        b = e["box"]
        x, y, w, h = b["x"], b["y"], b["w"], b["h"]
        draw.rectangle([x - 4, y - 4, x + w + 4, y + h + 4], outline=(255, 0, 0), width=3)
        label = e["id"]
        draw.rectangle([x - 4, y - 26, x - 4 + 10 * len(label) + 8, y - 4], fill=(255, 0, 0))
        draw.text((x, y - 24), label, fill=(255, 255, 255))
    buf = io.BytesIO()
    img.save(buf, format="JPEG", quality=88)
    return buf.getvalue(), img.size


def parse_response(text, group):
    text = re.sub(r"^```(?:json)?\s*|\s*```$", "", (text or "").strip())
    try:
        data = json.loads(text)
    except ValueError as error:
        raise JudgeOutputError("模型回應不是 JSON") from error
    if not isinstance(data, list) or not all(isinstance(d, dict) for d in data):
        raise JudgeOutputError("模型回應不是物件陣列")
    want = [e["id"] for e in group]
    got = [d.get("id") for d in data]
    if sorted(got) != sorted(want):
        raise JudgeOutputError(f"id 不符：缺 {set(want) - set(got)}，多 {set(got) - set(want)}")
    by_id = {e["id"]: e for e in group}
    out = {}
    for d in data:
        e = by_id[d["id"]]
        kind = d.get("kind") if d.get("kind") in KINDS else "other"
        translate = bool(d.get("translate")) and kind in TRANSLATABLE
        source = d.get("source") if isinstance(d.get("source"), str) and d.get("source").strip() else e["text"]
        translation = d.get("translation") if isinstance(d.get("translation"), str) else None
        flags = []
        if not has_letters(e["text"]):
            translate = False  # symbols only ("?????", "!!"): nothing to translate, keep the original
            flags.append("symbols_only")
        if e.get("conf", 0) >= 0.9 and similarity(e["text"], source) < 0.5:
            flags.append("source_rewritten")  # confident OCR overruled: keep OCR text, review later
            source = e["text"]
        if translate and not (translation or "").strip():
            raise JudgeOutputError(f"{d['id']} 標記翻譯但沒有譯文")
        out[d["id"]] = {"kind": kind, "translate": translate, "source": source,
                        "translation": translation.strip() if translate else None, "flags": flags}
    return out


def group_digest(group, language, context):
    """Cache key: a re-tracked run that changes ids, texts or timing must not reuse stale answers."""
    import hashlib
    key = [language, context, PROMPT] + [(e["id"], e["text"], round(e["start"], 2), round(e["end"], 2)) for e in group]
    return hashlib.sha256(json.dumps(key, ensure_ascii=False).encode()).hexdigest()[:12]


def judge_group(client, model, group, frame_path, *, language, dialogue, context, cache_dir, attempts=3):
    cache = Path(cache_dir) / f"{group[0]['id']}_{group[-1]['id']}_{group_digest(group, language, context)}.json"
    if cache.exists():
        return json.loads(cache.read_text(encoding="utf-8"))
    jpeg, (w, h) = annotated_jpeg(frame_path, group)
    items = "\n".join(
        f'- {e["id"]}: box=({e["box"]["x"]:.0f},{e["box"]["y"]:.0f},{e["box"]["w"]:.0f},{e["box"]["h"]:.0f}) '
        f'on screen {e["start"]:.1f}-{e["end"]:.1f}s, OCR text: "{e["text"]}"' for e in group)
    lines = dialogue_window(dialogue, group[0]["start"], max(e["end"] for e in group))
    prompt = PROMPT.format(
        language=LANGUAGE_NAMES.get(language, language), w=w, h=h, items=items,
        dialogue="\n".join(f"- {line}" for line in lines) or "(none)",
        context=f"\nShow notes: {context}\n" if context else "")
    url = "data:image/jpeg;base64," + base64.b64encode(jpeg).decode()
    error, content = None, None
    for attempt in range(attempts):
        try:
            reply = client.chat.completions.create(model=model, messages=[{"role": "user", "content": [
                {"type": "text", "text": prompt}, {"type": "image_url", "image_url": {"url": url}}]}])
            content = reply.choices[0].message.content
            result = parse_response(content, group)
            cache.parent.mkdir(parents=True, exist_ok=True)
            cache.write_text(json.dumps(result, ensure_ascii=False, indent=1), encoding="utf-8")
            return result
        except JudgeOutputError as exc:
            error = exc
            failures = Path(cache_dir) / "failures"
            failures.mkdir(parents=True, exist_ok=True)
            (failures / f"{group[0]['id']}_{group[-1]['id']}_{attempt + 1}.txt").write_text(
                f"{exc}\n\n{content}", encoding="utf-8")
        except Exception as exc:  # noqa: BLE001 - network / runtime hiccups are retried with backoff
            error = exc
            time.sleep(5 * (attempt + 1))
        print(f"  ⚠️ {group[0]['id']}..{group[-1]['id']} 第 {attempt + 1} 次失敗：{error}", file=sys.stderr)
    if isinstance(error, JudgeOutputError):
        if len(group) > 1:
            mid = len(group) // 2
            result = {}
            for part in (group[:mid], group[mid:]):
                result.update(judge_group(client, model, part, frame_path, language=language, dialogue=dialogue,
                                          context=context, cache_dir=cache_dir, attempts=attempts))
            return result
        # One item the model keeps answering badly: leave it untouched rather than abort an hour-long
        # run. Not cached, so the next run asks again; the flag surfaces it in the review sheet.
        e = group[0]
        print(f"  ⏭️ {e['id']} 放棄判讀，保留原文", file=sys.stderr)
        return {e["id"]: {"kind": "other", "translate": False, "source": e["text"], "translation": None,
                          "flags": ["judge_failed"]}}
    raise RuntimeError(f"判讀失敗 {group[0]['id']}..{group[-1]['id']}: {error}")


def judge_events(events, groups, frame_path_for, *, client, model, language="zh-TW", dialogue=(),
                 context="", cache_dir, concurrency=2, progress=None):
    results = {}

    def one(group):
        return judge_group(client, model, group, frame_path_for(key_frame(group)), language=language,
                           dialogue=dialogue, context=context, cache_dir=cache_dir)

    with ThreadPoolExecutor(max_workers=concurrency) as pool:
        for i, result in enumerate(pool.map(one, groups), 1):
            results.update(result)
            if progress:
                progress(i, len(groups))
    return [{**e, **results[e["id"]]} for e in events]
