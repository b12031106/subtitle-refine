"""Erase source captions by inpainting their glyphs (LaMa), instead of blurring a rectangle.

Needs the optional `inpaint` extra: pip install 'subtitle-engine[inpaint]' (torch + opencv).
"""
import hashlib
import os
import urllib.request
from pathlib import Path

import numpy as np

LAMA_URL = "https://github.com/enesmsahin/simple-lama-inpainting/releases/download/v0.1.0/big-lama.pt"
LAMA_SHA256 = "7ba7aa7ac37a4d41fdbbeba3a2af7ead18058552997e3a3cd1a3b2210c9e6b4c"
MIN_COVERAGE = 0.15  # a glyph mask covering less of the caption box than this probably missed the text
CONTEXT = 96  # pixels of surroundings LaMa sees around the masked area


def require():
    """Raise a helpful error early (before OCR / LLM work) when the inpaint extra is missing."""
    missing = []
    for mod in ("torch", "cv2"):
        try:
            __import__(mod)
        except ImportError:
            missing.append(mod)
    if missing:
        raise RuntimeError(f"--cover lama 需要 {', '.join(missing)}：pip install 'subtitle-engine[inpaint]'")


def glyph_mask(frame_rgb, box):
    """Caption-shaped mask from stroke contrast inside the caption box (no colour assumptions).

    Returns (mask uint8 0/1 of the full frame, coverage = masked share of the caption box).
    """
    import cv2
    H, W = frame_rgb.shape[:2]
    h = box["h"]
    pad = 0.15 * h
    x0, y0 = int(max(0, box["x"] - pad)), int(max(0, box["y"] - pad))
    x1, y1 = int(min(W, box["x"] + box["w"] + pad)), int(min(H, box["y"] + box["h"] + pad))
    full = np.zeros((H, W), np.uint8)
    if x1 - x0 < 4 or y1 - y0 < 4:
        return full, 0.0
    gray = cv2.cvtColor(np.ascontiguousarray(frame_rgb[y0:y1, x0:x1]), cv2.COLOR_RGB2GRAY)
    grad = cv2.morphologyEx(gray, cv2.MORPH_GRADIENT, np.ones((3, 3), np.uint8))
    edges = (grad > 70).astype(np.uint8)
    k = max(3, int(0.16 * h)) | 1
    blobs = cv2.morphologyEx(edges, cv2.MORPH_CLOSE, cv2.getStructuringElement(cv2.MORPH_ELLIPSE, (k, k)))
    n, lab, stats, _ = cv2.connectedComponentsWithStats(blobs)
    big = np.zeros(n, bool)
    big[1:] = stats[1:, cv2.CC_STAT_AREA] >= 0.02 * h * h  # drop specks
    keep = big[lab].astype(np.uint8)
    g = max(3, int(0.06 * h)) | 1
    keep = cv2.dilate(keep, cv2.getStructuringElement(cv2.MORPH_ELLIPSE, (g, g)))
    full[y0:y1, x0:x1] = keep
    bx0, by0 = int(max(0, box["x"])), int(max(0, box["y"]))
    bx1, by1 = int(min(W, box["x"] + box["w"])), int(min(H, box["y"] + box["h"]))
    area = max(1, (bx1 - bx0) * (by1 - by0))
    coverage = float(full[by0:by1, bx0:bx1].sum()) / area
    return full, coverage


def model_path():
    """LAMA_MODEL, else the torch-hub cache (shared with simple-lama-inpainting); downloaded and verified once."""
    if os.environ.get("LAMA_MODEL"):
        path = Path(os.environ["LAMA_MODEL"])
        if not path.exists():
            raise FileNotFoundError(f"LAMA_MODEL 指向的模型不存在：{path}")
        return path
    hub = Path(os.environ.get("TORCH_HOME", Path.home() / ".cache" / "torch")) / "hub" / "checkpoints"
    path = hub / "big-lama.pt"
    if not path.exists():
        hub.mkdir(parents=True, exist_ok=True)
        tmp = path.with_suffix(".part")
        print(f"⬇️  下載 LaMa 模型（約 200 MB）→ {path}", flush=True)
        urllib.request.urlretrieve(LAMA_URL, tmp)
        digest = hashlib.sha256(tmp.read_bytes()).hexdigest()
        if digest != LAMA_SHA256:
            tmp.unlink()
            raise RuntimeError(f"LaMa 模型 sha256 不符：{digest}")
        tmp.replace(path)
    return path


def pick_device(name=None):
    import torch
    if name:
        return torch.device(name)
    if torch.backends.mps.is_available():
        return torch.device("mps")
    if torch.cuda.is_available():
        return torch.device("cuda")
    return torch.device("cpu")


class Lama:
    """Big-LaMa torchscript; runs on a crop around the mask and changes only masked pixels."""

    def __init__(self, device=None):
        import torch
        self.torch = torch
        self.device = pick_device(device)
        self.model = torch.jit.load(str(model_path()), map_location="cpu").to(self.device).eval()  # saved on CUDA

    def __call__(self, frame_rgb, mask):
        ys, xs = np.nonzero(mask)
        if not len(ys):
            return frame_rgb
        H, W = mask.shape
        x0, y0 = max(0, xs.min() - CONTEXT), max(0, ys.min() - CONTEXT)
        x1, y1 = min(W, xs.max() + 1 + CONTEXT), min(H, ys.max() + 1 + CONTEXT)
        img = frame_rgb[y0:y1, x0:x1]
        m = mask[y0:y1, x0:x1]
        h, w = m.shape
        ph, pw = -h % 8, -w % 8
        t_img = np.pad(img, ((0, ph), (0, pw), (0, 0)), mode="symmetric").astype(np.float32) / 255
        t_mask = np.pad(m, ((0, ph), (0, pw)), mode="symmetric").astype(np.float32)
        torch = self.torch
        with torch.inference_mode():
            a = torch.from_numpy(t_img).permute(2, 0, 1)[None].to(self.device)
            b = (torch.from_numpy(t_mask)[None, None] > 0).float().to(self.device)
            res = self.model(a, b)[0].permute(1, 2, 0).cpu().numpy()
        res = np.clip(res[:h, :w] * 255, 0, 255).astype(np.uint8)
        out = frame_rgb.copy()
        out[y0:y1, x0:x1] = np.where(m[..., None] > 0, res, img)
        return out
