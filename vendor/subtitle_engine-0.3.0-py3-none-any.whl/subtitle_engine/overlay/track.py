"""Turn per-frame OCR boxes into on-screen text events."""
import difflib
import re
from statistics import median


def norm(text):
    return re.sub(r"\s+", "", text)


def similarity(a, b):
    return difflib.SequenceMatcher(None, norm(a), norm(b)).ratio()


def iou(a, b):
    ix = max(0.0, min(a["x"] + a["w"], b["x"] + b["w"]) - max(a["x"], b["x"]))
    iy = max(0.0, min(a["y"] + a["h"], b["y"] + b["h"]) - max(a["y"], b["y"]))
    inter = ix * iy
    union = a["w"] * a["h"] + b["w"] * b["h"] - inter
    return inter / union if union > 0 else 0.0


def has_letters(text):
    return any(ch.isalpha() for ch in text)


def track(rows, fps, *, min_obs=2, max_gap=2, min_similarity=0.6, min_iou=0.3,
          static_seconds=None, duration=None):
    """rows: OCR rows in frame order, each {"items": [{text, conf, x, y, w, h}]}.

    Returns events sorted by start time. A track survives `max_gap` missed frames (OCR flicker).
    Text that sits at the same place for long in total (show logo, watermark) is dropped even when
    scene cuts split it into many short tracks.
    """
    tracks, active = [], []
    for fi, row in enumerate(rows):
        t = fi / fps
        kept, used = [], set()
        for tr in active:
            last = tr["obs"][-1]
            best, best_score = None, 0.0
            for k, item in enumerate(row["items"]):
                if k in used:
                    continue
                sim, ov = similarity(last["text"], item["text"]), iou(last, item)
                if sim >= min_similarity and ov >= min_iou and sim + ov > best_score:
                    best, best_score = k, sim + ov
            if best is not None:
                used.add(best)
                tr["obs"].append({**row["items"][best], "fi": fi, "t": t})
                tr["gap"] = 0
                kept.append(tr)
            elif tr["gap"] < max_gap:
                tr["gap"] += 1
                kept.append(tr)
            else:
                tracks.append(tr)
        kept += [{"obs": [{**item, "fi": fi, "t": t}], "gap": 0}
                 for k, item in enumerate(row["items"]) if k not in used]
        active = kept
    tracks += active

    duration = duration if duration is not None else len(rows) / fps
    static_seconds = static_seconds if static_seconds is not None else max(20.0, 0.15 * duration)
    presence = {}
    for tr in tracks:
        o = tr["obs"][0]
        key = static_key(o)
        presence[key] = presence.get(key, 0.0) + len(tr["obs"]) / fps

    frame_w = max((r.get("w") or 0) for r in rows) if rows else 0
    events = []
    for tr in tracks:
        obs = tr["obs"]
        if len(obs) < min_obs or presence[static_key(obs[0])] >= static_seconds:
            continue
        best = max(obs, key=lambda o: (o["conf"], len(o["text"])))
        motion = classify_motion(obs, frame_w)
        events.append({
            "text": best["text"],
            "conf": best["conf"],
            "start": obs[0]["t"],
            "end": obs[-1]["t"] + 1 / fps,
            "box": extent(obs, full=motion == "scrolling"),
            "obs": [{k: o[k] for k in ("t", "x", "y", "w", "h")} for o in obs],
            "frames": [o["fi"] for o in obs],
            "moving": motion == "moving",
            "motion": motion,
        })
    events.sort(key=lambda e: (e["start"], e["box"]["y"]))
    for i, e in enumerate(events):
        e["id"] = f"e{i + 1:04d}"
    return events


def _pct(values, q):
    s = sorted(values)
    return s[min(len(s) - 1, max(0, int(round(q * (len(s) - 1)))))]


def _std(values):
    m = sum(values) / len(values)
    return (sum((v - m) ** 2 for v in values) / len(values)) ** 0.5


def classify_motion(obs, frame_w):
    """"static", "moving" (whole box travels) or "scrolling" (a line wider than the screen slides by).

    OCR often clips or extends one side of a static line (neighbouring glyphs, split words), so a
    box only counts as moving when both its left and right edges travel.
    """
    h = median(o["h"] for o in obs)
    if frame_w and len(obs) >= 3:
        at_edge = sum(1 for o in obs if o["x"] <= 2 or o["x"] + o["w"] >= frame_w - 2)
        if at_edge >= 0.3 * len(obs):
            return "scrolling"
    lefts = [o["x"] for o in obs]
    rights = [o["x"] + o["w"] for o in obs]
    centers_y = [o["y"] + o["h"] / 2 for o in obs]
    if min(_std(lefts), _std(rights)) > 0.3 * h or _std(centers_y) > 0.3 * h:
        return "moving"
    return "static"


def extent(obs, *, full=False):
    """Box that covers the text in (nearly) every observation; full=True takes the complete union."""
    lo, hi = (0.0, 1.0) if full else (0.1, 0.9)
    x0 = _pct([o["x"] for o in obs], lo)
    y0 = _pct([o["y"] for o in obs], lo)
    x1 = _pct([o["x"] + o["w"] for o in obs], hi)
    y1 = _pct([o["y"] + o["h"] for o in obs], hi)
    return {"x": float(x0), "y": float(y0), "w": float(max(1, x1 - x0)), "h": float(max(1, y1 - y0))}


def static_key(o):
    cx, cy = o["x"] + o["w"] / 2, o["y"] + o["h"] / 2
    return norm(o["text"]).lower(), round(cx / 40), round(cy / 40)


def groups_of(events, *, max_events=6, max_span=6.0):
    """Events on screen together share one LLM call."""
    groups, cur, cur_end = [], [], -1.0
    for e in events:
        if cur and (e["start"] >= cur_end or len(cur) >= max_events or e["start"] - cur[0]["start"] > max_span):
            groups.append(cur)
            cur, cur_end = [], -1.0
        cur.append(e)
        cur_end = max(cur_end, e["end"])
    if cur:
        groups.append(cur)
    return groups


def key_frame(group):
    """Frame index where the most events of the group are visible (ties: the later-ending view)."""
    counts = {}
    for e in group:
        for fi in e["frames"]:
            counts[fi] = counts.get(fi, 0) + 1
    best = max(counts.values())
    candidates = sorted(fi for fi, c in counts.items() if c == best)
    return candidates[len(candidates) // 2]


def box_at(event, t):
    """Interpolated box for moving events; the median box otherwise."""
    if not event.get("moving"):
        return event["box"]
    obs = event["obs"]
    if t <= obs[0]["t"]:
        return obs[0]
    for a, b in zip(obs, obs[1:]):
        if a["t"] <= t <= b["t"]:
            f = (t - a["t"]) / (b["t"] - a["t"]) if b["t"] > a["t"] else 0
            return {k: a[k] + (b[k] - a[k]) * f for k in ("x", "y", "w", "h")}
    return obs[-1]
