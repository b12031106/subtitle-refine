"""Apple Vision OCR (macOS) through a small compiled Swift helper.

The helper is compiled once per source hash into the user cache directory, so the package ships
no binaries. Boxes come back in pixels with a top-left origin.
"""
import hashlib
import json
import os
import platform
import shutil
import subprocess
from concurrent.futures import ThreadPoolExecutor
from pathlib import Path

SWIFT_SOURCE = r'''
import Foundation
import Vision
import AppKit
// usage: ocr --langs | ocr <list-file> <lang,lang,...> <min-text-height>
// list-file: one image path per line. Output: one JSON object per image on stdout.
let args = CommandLine.arguments
if args.count > 1 && args[1] == "--langs" {
    let r = VNRecognizeTextRequest(); r.recognitionLevel = .accurate
    let langs = (try? r.supportedRecognitionLanguages()) ?? []
    print(String(data: try! JSONSerialization.data(withJSONObject: langs), encoding: .utf8)!)
    exit(0)
}
let paths = try String(contentsOfFile: args[1], encoding: .utf8).split(separator: "\n").map(String.init)
let langs = args[2].split(separator: ",").map(String.init)
let minHeight = Float(args[3]) ?? 0.02
for p in paths where !p.isEmpty {
    let url = URL(fileURLWithPath: p)
    var items: [[String: Any]] = []
    var W = 0.0, H = 0.0
    if let img = NSImage(contentsOf: url), let cg = img.cgImage(forProposedRect: nil, context: nil, hints: nil) {
        W = Double(cg.width); H = Double(cg.height)
        let req = VNRecognizeTextRequest()
        req.recognitionLevel = .accurate
        req.recognitionLanguages = langs
        req.usesLanguageCorrection = true
        req.minimumTextHeight = minHeight
        try? VNImageRequestHandler(cgImage: cg).perform([req])
        for o in req.results ?? [] {
            guard let c = o.topCandidates(1).first else { continue }
            let b = o.boundingBox
            items.append(["text": c.string, "conf": Double(c.confidence),
                          "x": (b.minX * W).rounded(), "y": ((1 - b.minY - b.height) * H).rounded(),
                          "w": (b.width * W).rounded(), "h": (b.height * H).rounded()])
        }
    }
    let line: [String: Any] = ["frame": url.lastPathComponent, "w": W, "h": H, "items": items]
    print(String(data: try JSONSerialization.data(withJSONObject: line, options: [.sortedKeys]), encoding: .utf8)!)
    fflush(stdout)
}
'''


class OCRUnavailable(RuntimeError):
    pass


def helper_path():
    if platform.system() != "Darwin":
        raise OCRUnavailable("畫面字幕 OCR 目前只支援 macOS（Apple Vision）")
    digest = hashlib.sha256(SWIFT_SOURCE.encode()).hexdigest()[:16]
    cache = Path(os.environ.get("XDG_CACHE_HOME", Path.home() / ".cache")) / "subtitle-engine"
    binary = cache / f"vision-ocr-{digest}"
    if binary.exists():
        return binary
    swiftc = shutil.which("swiftc")
    if not swiftc:
        raise OCRUnavailable("找不到 swiftc；請安裝 Xcode Command Line Tools")
    cache.mkdir(parents=True, exist_ok=True)
    source = cache / f"vision-ocr-{digest}.swift"
    source.write_text(SWIFT_SOURCE)
    tmp = binary.with_suffix(".tmp")
    subprocess.run([swiftc, "-O", str(source), "-o", str(tmp)], check=True, capture_output=True)
    tmp.replace(binary)
    return binary


def supported_languages():
    out = subprocess.run([str(helper_path()), "--langs"], check=True, capture_output=True, text=True).stdout
    return json.loads(out)


def ocr_frames(frames, out_jsonl, *, languages=("ko-KR", "en-US"), min_text_height=0.02, workers=4):
    """OCR every image in `frames` (sorted paths) into `out_jsonl`; resumes from a partial file."""
    out_jsonl = Path(out_jsonl)
    done = {}
    if out_jsonl.exists():
        for line in out_jsonl.read_text().splitlines():
            try:
                row = json.loads(line)
                done[row["frame"]] = row
            except (ValueError, KeyError):
                continue  # torn last line from an interrupted run
    todo = [Path(f) for f in frames if Path(f).name not in done]
    if todo:
        binary = str(helper_path())
        work = out_jsonl.parent / (out_jsonl.name + ".parts")
        work.mkdir(parents=True, exist_ok=True)

        def run(i, shard):
            if not shard:
                return []
            lst = work / f"shard{i}.txt"
            lst.write_text("\n".join(str(p) for p in shard))
            res = subprocess.run([binary, str(lst), ",".join(languages), str(min_text_height)],
                                 check=True, capture_output=True, text=True)
            return [json.loads(l) for l in res.stdout.splitlines() if l.strip()]

        batch = 200 * workers  # append after every batch so an interrupted run resumes
        with ThreadPoolExecutor(max_workers=workers) as pool, out_jsonl.open("a") as sink:
            for start in range(0, len(todo), batch):
                part = todo[start:start + batch]
                for rows in pool.map(run, range(workers), [part[i::workers] for i in range(workers)]):
                    for row in rows:
                        done[row["frame"]] = row
                        sink.write(json.dumps(row, ensure_ascii=False) + "\n")
                sink.flush()
        shutil.rmtree(work, ignore_errors=True)
    return [done[Path(f).name] for f in frames if Path(f).name in done]
