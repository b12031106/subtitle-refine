"""In-place translation of post-production on-screen captions (macOS Vision OCR + vision LLM)."""
