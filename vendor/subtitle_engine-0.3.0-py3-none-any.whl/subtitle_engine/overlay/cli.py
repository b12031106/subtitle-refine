"""Translate post-production on-screen captions in place (fansub style).

    python -m subtitle_engine.overlay VIDEO --out-dir DIR [--target zh-TW] [--dialogue-srt FILE]
                                     [--start SEC --duration SEC] [--provider local-runtime|openai]
                                     [--cover blur|lama]

Every stage is cached under DIR/<stem>.onscreen-work/, so an interrupted run resumes.
"""
import argparse
import json
import re
import subprocess
import sys
import time
from collections import Counter
from pathlib import Path

from . import judge as judge_mod
from . import ocr as ocr_mod
from . import render, track


def log(msg):
    print(msg, flush=True)


def parse_srt(path, offset=0.0):
    def ts(s):
        h, m, rest = s.strip().replace(",", ".").split(":")
        return int(h) * 3600 + int(m) * 60 + float(rest)
    out = []
    for block in re.split(r"\n\s*\n", Path(path).read_text(encoding="utf-8-sig").strip()):
        lines = block.splitlines()
        if len(lines) >= 3 and "-->" in lines[1]:
            a, b = lines[1].split("-->")
            out.append((ts(a) - offset, ts(b) - offset, " ".join(lines[2:]).strip()))
    return out


def build_parser():
    p = argparse.ArgumentParser(prog="subtitle-engine-overlay", description=__doc__,
                                formatter_class=argparse.RawDescriptionHelpFormatter)
    p.add_argument("video")
    p.add_argument("--out-dir", required=True)
    p.add_argument("--target", default="zh-TW", help="翻譯目標語言（預設 zh-TW）")
    p.add_argument("--dialogue-srt", help="已翻譯的對白字幕，提供 LLM 上下文與一致的人名")
    p.add_argument("--context", default="", help="節目資訊／人名對照，例如 '박은영 = 朴恩英'")
    p.add_argument("--provider", default="local-runtime", choices=["local-runtime", "openai"])
    p.add_argument("--model")
    p.add_argument("--start", type=float, help="只處理片段：起始秒數")
    p.add_argument("--duration", type=float, help="只處理片段：長度秒數")
    p.add_argument("--sample-fps", type=float, default=5.0, help="OCR 抽樣頻率（預設 5）")
    p.add_argument("--ocr-languages", default="ko-KR,en-US")
    p.add_argument("--ocr-workers", type=int, default=4)
    p.add_argument("--concurrency", type=int, default=2, help="同時進行的 LLM 判讀數")
    p.add_argument("--font", default="PingFang TC")
    p.add_argument("--crf", type=int, default=19)
    p.add_argument("--render-workers", type=int, default=4, help="平行合成的程序數（僅 blur）")
    p.add_argument("--cover", default="blur", choices=["blur", "lama"],
                   help="原文的遮蓋方式：blur＝模糊底（預設）；lama＝用 LaMa 修補抹除原文字形，"
                        "不留模糊底（需 pip install 'subtitle-engine[inpaint]'，整集約數小時，可中斷續跑）")
    p.add_argument("--inpaint-device", help="LaMa 使用的裝置（預設自動：mps → cuda → cpu）")
    p.add_argument("--no-review", action="store_true", help="不產生 HTML 驗收頁")
    p.add_argument("--stop-after", choices=["ocr", "events", "judge", "ass"], help="除錯用：做到指定階段即停止")
    return p


def main(argv=None):
    args = build_parser().parse_args(argv)
    from ..processor import get_ffmpeg_path, load_dotenv
    load_dotenv()
    ffmpeg = get_ffmpeg_path()
    if args.cover == "lama":
        from .inpaint import require
        require()  # fail now, not after OCR and the LLM judge
    video = Path(args.video).resolve()
    out_dir = Path(args.out_dir).resolve()
    stem = video.stem + (f".{args.start:g}s+{args.duration:g}s" if args.start is not None else "")
    work = out_dir / f"{stem}.onscreen-work"
    work.mkdir(parents=True, exist_ok=True)
    began = time.time()

    source, offset = video, 0.0
    if args.start is not None:
        offset = args.start
        source = work / "clip.mp4"
        if not source.exists():
            log(f"✂️  擷取片段 {args.start:g}s +{args.duration:g}s")
            tmp = work / "clip.tmp.mp4"
            subprocess.run([ffmpeg, "-v", "error", "-y", "-ss", str(args.start), "-i", str(video),
                            *(["-t", str(args.duration)] if args.duration else []),
                            "-c:v", "libx264", "-preset", "veryfast", "-crf", "14", "-c:a", "aac", "-b:a", "192k",
                            str(tmp)], check=True)
            tmp.replace(source)
    meta = render.probe(source, ffmpeg)
    log(f"🎬 {meta['w']}x{meta['h']} {meta['fps']:.3f}fps {meta['duration'] / 60:.1f} 分鐘")

    frames_dir = work / "frames"
    expected = int(meta["duration"] * args.sample_fps)
    frames = sorted(frames_dir.glob("*.jpg")) if frames_dir.exists() else []
    if len(frames) < expected - 2:
        log(f"🖼️  抽格 {args.sample_fps:g} fps（約 {expected} 張）")
        frames_dir.mkdir(exist_ok=True)
        subprocess.run([ffmpeg, "-v", "error", "-y", "-i", str(source), "-vf", f"fps={args.sample_fps}",
                        "-q:v", "3", str(frames_dir / "%06d.jpg")], check=True)
        frames = sorted(frames_dir.glob("*.jpg"))

    log(f"🔤 OCR（Apple Vision，{args.ocr_workers} 平行）")
    rows = ocr_mod.ocr_frames(frames, work / "ocr.jsonl", languages=args.ocr_languages.split(","),
                              workers=args.ocr_workers)
    if args.stop_after == "ocr":
        return 0

    events_path = work / "events.json"
    if events_path.exists():
        events = json.loads(events_path.read_text(encoding="utf-8"))
    else:
        events = track.track(rows, args.sample_fps, duration=meta["duration"])
        events_path.write_text(json.dumps(events, ensure_ascii=False, indent=1), encoding="utf-8")
    groups = track.groups_of(events)
    log(f"🧩 {len(events)} 個文字事件 → {len(groups)} 次 LLM 判讀")
    if args.stop_after == "events":
        return 0

    dialogue = parse_srt(args.dialogue_srt, offset) if args.dialogue_srt else []
    client, model = judge_mod.make_client(args.provider, args.model)
    started = time.time()

    def progress(i, n):
        if i % 10 == 0 or i == n:
            log(f"  🤖 判讀 {i}/{n}（{time.time() - started:.0f}s）")

    judged = judge_mod.judge_events(
        events, groups, lambda fi: frames[fi], client=client, model=model, language=args.target,
        dialogue=dialogue, context=args.context, cache_dir=work / "judge", concurrency=args.concurrency,
        progress=progress)
    if args.stop_after == "judge":
        return 0

    from PIL import Image
    shown = [e for e in judged if e["translate"]]
    for e in shown:
        mid = e["frames"][len(e["frames"]) // 2]
        with Image.open(frames[mid]) as im:
            colors = render.measure_colors(im.convert("RGB"), e["box"])
        e["fill"], e["outline"] = colors or ("#FFFFFF", "#000000")
        if not colors:
            e["flags"].append("color_fallback")
        e["layout"] = render.layout(e, meta["w"], meta["h"])
    log("⏱️  校正出現／消失時間（原生影格）")
    render.refine_boundaries(shown, source, meta, ffmpeg, sample_fps=args.sample_fps)
    render.plan_transitions(judged, meta["fps"])

    base = out_dir / f"{stem}.{args.target}.onscreen"
    ass_path = base.with_suffix(".ass")
    render.write_ass(judged, meta["w"], meta["h"], ass_path, font=args.font)
    keep = ("id", "start", "end", "box", "moving", "text", "kind", "translate", "source", "translation",
            "flags", "fill", "outline")
    base.with_suffix(".json").write_text(json.dumps(
        [{k: e[k] for k in keep if k in e} for e in judged], ensure_ascii=False, indent=1), encoding="utf-8")
    if args.stop_after == "ass":
        return 0

    suffix = "" if args.cover == "blur" else f"_{args.cover}"
    out_video = out_dir / f"{stem}_onscreen_{args.target}{suffix}.mp4"
    parts_dir = None
    if args.cover != "blur":
        import hashlib
        from .. import __version__
        key = hashlib.sha256(ass_path.read_bytes() + f"{args.cover}|{args.crf}|{__version__}".encode()).hexdigest()[:12]
        parts_dir = work / f"render-{args.cover}-{key}"
    log(f"🎨 合成 {len(shown)} 段畫面字翻譯（遮蓋：{args.cover}）")
    render.composite(source, judged, ass_path, out_video, meta, ffmpeg, crf=args.crf, workers=args.render_workers,
                     log=log, cover=args.cover, parts_dir=parts_dir, device=args.inpaint_device)
    review_html = None
    if not args.no_review:
        from .review import write_review
        log("📝 產生驗收頁（原畫面／成品對照）")
        review_html = write_review(judged, source, out_video, base.parent / f"{base.stem}{suffix}.review.html", meta, ffmpeg,
                                   f"{video.stem}（{args.target}）")

    kinds = Counter(e["kind"] for e in judged)
    flags = Counter(f for e in judged for f in e["flags"])
    log("=" * 60)
    log(f"✅ 完成（{(time.time() - began) / 60:.1f} 分鐘）：{out_video}")
    log(f"   ASS：{ass_path}")
    if review_html:
        log(f"   驗收頁：{review_html}")
    log(f"   事件：{len(judged)}，翻譯 {len(shown)}；類別 {dict(kinds)}")
    if flags:
        log(f"   待檢查：{dict(flags)}（詳見 {base.with_suffix('.json').name} 的 flags）")
    return 0


if __name__ == "__main__":
    sys.exit(main())
