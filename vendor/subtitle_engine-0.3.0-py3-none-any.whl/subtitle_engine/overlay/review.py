"""Self-contained HTML review sheet: original vs. rendered crop for every event."""
import base64
import html
import io
import subprocess
from concurrent.futures import ThreadPoolExecutor
from pathlib import Path

from PIL import Image

KIND_LABEL = {"speech_caption": "對白字", "comment_caption": "旁白／吐槽", "title_card": "標題",
              "logo": "台標", "clothing_or_prop": "衣物／道具", "background_sign": "招牌／背景", "other": "其他"}


def _frame_at(ffmpeg, video, t):
    out = subprocess.run([ffmpeg, "-v", "error", "-ss", f"{max(0.0, t):.3f}", "-i", str(video), "-frames:v", "1",
                          "-f", "image2pipe", "-vcodec", "png", "-"], capture_output=True)
    return Image.open(io.BytesIO(out.stdout)).convert("RGB") if out.stdout else None


def _crop(img, box, W, H, width=420):
    if img is None:
        return ""
    m = 0.8 * box["h"]
    x0, y0 = max(0, box["x"] - m), max(0, box["y"] - m)
    x1, y1 = min(W, box["x"] + box["w"] + m), min(H, box["y"] + box["h"] + m)
    crop = img.crop((int(x0), int(y0), int(x1), int(y1)))
    if crop.width > width:
        crop = crop.resize((width, max(1, int(crop.height * width / crop.width))))
    buf = io.BytesIO()
    crop.save(buf, format="JPEG", quality=72)
    return "data:image/jpeg;base64," + base64.b64encode(buf.getvalue()).decode()


def _tc(t):
    return f"{int(t // 60):02d}:{t % 60:05.2f}"


def write_review(events, source, rendered, out_html, meta, ffmpeg, title):
    W, H = meta["w"], meta["h"]

    def shots(e):
        mid = (e["start"] + e["end"]) / 2
        before = _crop(_frame_at(ffmpeg, source, mid), e["box"], W, H)
        after = _crop(_frame_at(ffmpeg, rendered, mid), e["box"], W, H) if e.get("translate") else ""
        return before, after

    with ThreadPoolExecutor(max_workers=6) as pool:
        images = list(pool.map(shots, events))

    def row(e, imgs):
        before, after = imgs
        flags = " ".join(f'<span class="flag">{html.escape(f)}</span>' for f in e.get("flags", []))
        return (f'<tr id="{e["id"]}"><td class="meta"><b>{e["id"]}</b><br>{_tc(e["start"])}–{_tc(e["end"])}'
                f'<br><span class="kind">{KIND_LABEL.get(e["kind"], e["kind"])}</span>{"<br>" + flags if flags else ""}</td>'
                f'<td><img src="{before}" loading="lazy"></td>'
                f'<td>{f"<img src={chr(34)}{after}{chr(34)} loading=lazy>" if after else ""}</td>'
                f'<td class="txt"><div class="ko">{html.escape(e.get("source") or e["text"])}</div>'
                f'<div class="zh">{html.escape(e.get("translation") or "—")}</div></td></tr>')

    translated = [(e, i) for e, i in zip(events, images) if e.get("translate")]
    skipped = [(e, i) for e, i in zip(events, images) if not e.get("translate")]
    flagged = sum(1 for e in events if e.get("flags"))
    head = "<tr><th>事件</th><th>原畫面</th><th>成品</th><th>原文／譯文</th></tr>"
    page = f"""<!doctype html><html lang="zh-Hant"><meta charset="utf-8">
<meta name="viewport" content="width=device-width,initial-scale=1"><title>畫面字幕驗收</title>
<style>
:root{{--bg:#fff;--fg:#1d1d1f;--muted:#6e6e73;--line:#e5e5ea;--flag:#b3261e}}
@media (prefers-color-scheme:dark){{:root{{--bg:#151516;--fg:#f2f2f7;--muted:#a1a1a6;--line:#2c2c2e;--flag:#ff8a80}}}}
body{{background:var(--bg);color:var(--fg);font:15px/1.5 -apple-system,"PingFang TC",sans-serif;margin:0 16px 48px}}
h1{{font-size:22px;margin:24px 0 4px}} p.sub{{color:var(--muted);margin:0 0 16px}}
table{{border-collapse:collapse;width:100%}} td,th{{border-bottom:1px solid var(--line);padding:8px;vertical-align:top;text-align:left}}
th{{color:var(--muted);font-weight:500;font-size:13px}} img{{max-width:100%;border-radius:4px;display:block}}
td.meta{{white-space:nowrap;font-size:13px;color:var(--muted)}} .kind{{color:var(--fg)}}
.flag{{color:var(--flag);font-size:12px}} .ko{{color:var(--muted)}} .zh{{font-size:17px}}
details{{margin-top:24px}} summary{{cursor:pointer;font-size:17px}}
@media (max-width:700px){{td,th{{padding:6px 4px}} .zh{{font-size:15px}}}}
</style>
<h1>{html.escape(title)}</h1>
<p class="sub">文字事件 {len(events)}・翻譯 {len(translated)}・未翻譯 {len(skipped)}・待檢查 {flagged}</p>
<table>{head}{"".join(row(e, i) for e, i in translated)}</table>
<details><summary>未翻譯的文字（{len(skipped)}）：確認判斷是否正確</summary>
<table>{head}{"".join(row(e, i) for e, i in skipped)}</table></details>
</html>"""
    Path(out_html).write_text(page, encoding="utf-8")
    return out_html
