"""Styling, frame-accurate timing, ASS generation and the blur compositor."""
import shutil
import subprocess
import sys
import tempfile
import time
from pathlib import Path

import numpy as np

from .track import box_at

FADE = 0.08  # seconds; ASS \fad and the blur alpha ramp use the same value


# ------------------------------------------------------------------ style
def measure_colors(frame_rgb, box):
    """(fill, outline) as #RRGGBB, measured from pixels; None when the text cannot be isolated.

    Text pixels are the ones furthest from the surrounding background; among them the dark ones are
    the stroke and the brightest half of the rest is the fill (avoids anti-aliased edges).
    """
    img = np.asarray(frame_rgb, dtype=float)
    H, W, _ = img.shape
    x, y = int(max(0, box["x"])), int(max(0, box["y"]))
    w, h = int(min(W - x, box["w"])), int(min(H - y, box["h"]))
    if w <= 2 or h <= 2:
        return None
    hexof = lambda c: "#%02X%02X%02X" % tuple(int(round(v)) for v in c)
    m = int(0.6 * h)
    x0, y0 = max(0, x - m), max(0, y - m)
    ring = img[y0:min(H, y + h + m), x0:min(W, x + w + m)]
    mask = np.ones(ring.shape[:2], bool)
    mask[y - y0:y - y0 + h, x - x0:x - x0 + w] = False
    inner = img[y:y + h, x:x + w].reshape(-1, 3)
    bg = np.median(ring[mask], axis=0) if mask.any() else np.median(inner, axis=0)
    stroked = _stroked_fill(img[y:y + h, x:x + w], h, bg)
    if stroked is not None:
        fill, outline = stroked
        return hexof(fill), hexof(outline)
    dist = np.linalg.norm(inner - bg, axis=1)
    text = inner[(dist >= np.percentile(dist, 65)) & (dist > 25)]  # >= keeps flat-colour ties
    lum = text @ np.array([0.299, 0.587, 0.114])
    dark, light = text[lum < 70], text[lum >= 110]
    if len(light) < 30:
        return None
    return hexof(dominant(light)), (hexof(np.median(dark, axis=0)) if len(dark) >= 30 else "#000000")


def _near(mask, k, dy, dx):
    """True where `mask` is set within 1..k pixels in direction (dy, dx)."""
    out = np.zeros_like(mask)
    H, W = mask.shape
    for s in range(1, k + 1):
        oy, ox = dy * s, dx * s
        src = mask[max(0, oy):H + min(0, oy), max(0, ox):W + min(0, ox)]
        out[max(0, -oy):H + min(0, -oy), max(0, -ox):W + min(0, -ox)] |= src
    return out


def _stroked_fill(crop, h, bg):
    """Variety captions are drawn with a dark stroke. Fill pixels are enclosed by stroke on both sides
    (left/right or up/down) — clothes behind the text touch it on one side only — and differ from the
    surrounding background — gaps between glyphs are enclosed too, but show the background."""
    lum = crop @ np.array([0.299, 0.587, 0.114])
    dark = lum < 75
    if dark.sum() < 30:
        return None
    k = max(3, int(0.3 * h))
    enclosed = ((_near(dark, k, 0, -1) & _near(dark, k, 0, 1)) |
                (_near(dark, k, -1, 0) & _near(dark, k, 1, 0)))
    far = np.linalg.norm(crop - bg, axis=2) > 45
    fill = crop[enclosed & far & ~dark & (lum >= 100)]
    if len(fill) < 30:
        return None
    return dominant(fill), np.median(crop[dark], axis=0)


def dominant(pixels, step=24):
    """Median of the most common colour bucket: caption fill is flat, while bright clothes or walls
    behind the text vary, so the mode is the fill even when brighter pixels are present."""
    buckets = (pixels // step).astype(int)
    keys = buckets[:, 0] * 10000 + buckets[:, 1] * 100 + buckets[:, 2]
    values, counts = np.unique(keys, return_counts=True)
    top = values[np.argmax(counts)]
    return np.median(pixels[keys == top], axis=0)


def text_width_em(text):
    width = 0.0
    for ch in text:
        if ch == " ":
            width += 0.3
        elif ord(ch) >= 0x2E80 or ch in "【】「」『』（），、！？：；…":
            width += 1.0
        else:
            width += 0.56
    return width


BREAKS = "，、。！？；：…） "


def wrap_two_lines(text):
    """Split near the middle, preferring punctuation; returns (first, second)."""
    mid = len(text) / 2
    # after a punctuation run, never inside one ("……", "！？")
    cuts = [i + 1 for i, ch in enumerate(text[:-1]) if ch in BREAKS and text[i + 1] not in BREAKS]
    cut = min(cuts, key=lambda i: abs(i - mid)) if cuts else int(round(mid))
    if not 0.25 * len(text) <= cut <= 0.75 * len(text):
        cut = int(round(mid))
    return text[:cut].rstrip(), text[cut:].lstrip()


def layout(event, W, H):
    """Font size, line breaks and cover size (centred on the source text) for one translated event."""
    b = dict(event["box"])
    obs = event.get("obs") or []
    if event.get("moving") and obs:  # the extent of a travelling box is its path, not its size
        b["w"] = float(np.median([o["w"] for o in obs]))
    if event.get("motion") in ("moving", "scrolling") and obs:
        b["h"] = float(np.median([o["h"] for o in obs]))  # line height, not the union's
    lines = [event["translation"]]
    line_h = b["h"]
    fs = line_h * 0.92
    em = max(1.0, text_width_em(lines[0]))
    # CJK glyphs run wider than Hangul: keep the original height and let the cover grow first
    if em * fs > b["w"] * 1.35:
        fs = max(line_h * 0.62, b["w"] * 1.35 / em)
    if em * fs > W * 0.94:  # still wider than the screen: shrink, wrap only as a last resort
        fs = W * 0.94 / em
        if fs < line_h * 0.45 and len(lines[0]) >= 6:
            lines = list(wrap_two_lines(lines[0]))
            em = max(text_width_em(line) for line in lines)
            fs = min(line_h * 0.92, W * 0.94 / em)
    text_w = em * fs
    # opaque core = source box + safety margin; the feather ramp lies entirely outside the source
    feather = 0.28 * line_h
    pad = 0.18 * line_h + feather
    # the cover must hide every observed position of the source, the font follows the line height
    src_h = b["h"] if event.get("moving") else event["box"]["h"]
    cover_w = min(W + 2 * pad, max(b["w"], text_w) + 2 * pad)
    cover_h = min(H, max(src_h, fs * 1.1 * len(lines)) + 2 * pad)
    return {"fs": round(fs, 1), "bord": round(max(2.0, fs * 0.09), 1), "cover_w": cover_w, "cover_h": cover_h,
            "feather": feather, "lines": lines}


def plan_transitions(events, fps, *, gap=0.15):
    """Hard cuts between back-to-back captions in the same place; one frame of safety margin.

    A fade at such a junction would leave both covers half transparent for a few frames and let the
    source text flash through. Covers also start/end one native frame early/late.
    """
    shown = sorted((e for e in events if e.get("translate")), key=lambda e: e["start"])
    for e in shown:
        e["fade_in"] = e["fade_out"] = True
    end_cut = {}
    for i, a in enumerate(shown):
        for b in shown[i + 1:]:
            if b["start"] - a["end"] > gap:
                break
            ya, yb = a["box"]["y"] + a["box"]["h"] / 2, b["box"]["y"] + b["box"]["h"] / 2
            if a["fade_out"] and b["fade_in"] and abs(ya - yb) < 0.6 * max(a["box"]["h"], b["box"]["h"]):
                a["fade_out"] = b["fade_in"] = False
                end_cut[id(a)] = b["start"]  # one shared cut: no overlap, no gap
    for e in shown:
        # the extra frame of margin only where there is a fade; a hard cut stays exactly on the cut
        if e["fade_in"]:
            e["start"] = max(0.0, e["start"] - 1 / fps)
        e["end"] = end_cut.get(id(e), e["end"] + 1 / fps) if not e["fade_out"] else e["end"] + 1 / fps
    return events


# ------------------------------------------------------------------ media helpers
def probe(video, ffmpeg):
    ffprobe = Path(ffmpeg).with_name("ffprobe")
    ffprobe = str(ffprobe) if ffprobe.exists() else (shutil.which("ffprobe") or "ffprobe")
    out = subprocess.run([ffprobe, "-v", "error", "-select_streams", "v:0", "-show_entries",
                          "stream=width,height,r_frame_rate:format=duration", "-of", "json", str(video)],
                         check=True, capture_output=True, text=True).stdout
    import json
    data = json.loads(out)
    s = data["streams"][0]
    num, den = s["r_frame_rate"].split("/")
    return {"w": int(s["width"]), "h": int(s["height"]), "fps": float(num) / float(den),
            "duration": float(data["format"]["duration"])}


def _frames(ffmpeg, video, w, h, pix_fmt, scale=None, *, start=None, count=None):
    vf = ["-vf", f"scale={scale[0]}:{scale[1]}"] if scale else []
    seek = ["-ss", f"{start:.6f}"] if start else []
    limit = ["-frames:v", str(count)] if count else []
    proc = subprocess.Popen([ffmpeg, "-v", "error", *seek, "-i", str(video), *vf, *limit,
                             "-f", "rawvideo", "-pix_fmt", pix_fmt, "-"],
                            stdout=subprocess.PIPE, stderr=subprocess.DEVNULL)
    ch = 3 if pix_fmt == "rgb24" else 1
    size = w * h * ch
    try:
        while True:
            buf = proc.stdout.read(size)
            if len(buf) < size:
                break
            yield np.frombuffer(buf, np.uint8).reshape(h, w, ch) if ch == 3 else np.frombuffer(buf, np.uint8).reshape(h, w)
    finally:
        if proc.poll() is None:
            proc.kill()  # stopped early on purpose
        proc.stdout.close()
        proc.wait()


# ------------------------------------------------------------------ timing
def refine_boundaries(events, video, meta, ffmpeg, *, sample_fps, low_w=640, min_change=6.0):
    """Snap start/end of static events to the native frame where the text region changes most.

    Sampling at `sample_fps` puts each boundary somewhere inside one sample interval; this scans that
    interval at the native frame rate on a low-resolution grey copy.
    """
    fps, W, H = meta["fps"], meta["w"], meta["h"]
    sx = low_w / W
    low_h = int(round(H * sx / 2) * 2)
    step = 1 / sample_fps
    windows = {}
    for e in events:
        if e.get("moving"):
            continue
        # start = first sample with the text, so it appeared in (start - step, start];
        # end = last sample with the text + step, so it vanished in (end - step, end]. Never look at
        # frames before the last sample that still showed it: a camera move there must not end it early.
        for which, (a, b) in (("start", (e["start"] - step - 0.05, e["start"] + 0.05)),
                              ("end", (e["end"] - step + 0.5 / fps, e["end"] + 0.05))):
            for n in range(max(1, int(a * fps)), int(b * fps) + 2):
                windows.setdefault(n, []).append((e, which))
    if not windows:
        return events
    diffs = {}
    last = max(windows)
    prev = None
    for n, frame in enumerate(_frames(ffmpeg, video, low_w, low_h, "gray", (low_w, low_h))):
        if n in windows and prev is not None:
            for e, which in windows[n]:
                b = e["box"]
                x0, y0 = int(b["x"] * sx), int(b["y"] * sx)
                x1, y1 = max(x0 + 2, int((b["x"] + b["w"]) * sx)), max(y0 + 2, int((b["y"] + b["h"]) * sx))
                d = float(np.abs(frame[y0:y1, x0:x1].astype(np.int16) - prev[y0:y1, x0:x1]).mean())
                diffs.setdefault((e["id"], which), []).append((d, n))
        prev = frame
        if n >= last:
            break
    for e in events:
        for which in ("start", "end"):
            found = diffs.get((e["id"], which))
            if found:
                d, n = max(found)
                if d >= min_change:
                    e[which] = n / fps
        if e["end"] - e["start"] < 0.2:
            e["end"] = e["start"] + 0.2
    return events


# ------------------------------------------------------------------ ASS
def ass_color(hex_):
    return f"&H00{hex_[5:7]}{hex_[3:5]}{hex_[1:3]}&".upper()


def ass_time(t):
    cs = max(0, int(round(t * 100)))
    return f"{cs // 360000}:{cs // 6000 % 60:02d}:{cs // 100 % 60:02d}.{cs % 100:02d}"


def ass_escape(text):
    return text.replace("\\", "＼").replace("{", "｛").replace("}", "｝").replace("\n", " ")


def write_ass(events, W, H, path, font="PingFang TC"):
    lines = []
    for e in events:
        if not e.get("translate"):
            continue
        L = e["layout"]
        base = (f"\\fs{L['fs']}\\c{ass_color(e['fill'])}\\3c{ass_color(e['outline'])}"
                f"\\bord{L['bord']}\\shad0\\b1")
        text = "\\N".join(ass_escape(line) for line in L.get("lines") or [e["translation"]])
        fin = int(FADE * 1000) if e.get("fade_in", True) else 0
        fout = int(FADE * 1000) if e.get("fade_out", True) else 0
        if not e.get("moving"):
            b = e["box"]
            pos = f"\\an5\\pos({b['x'] + b['w'] / 2:.0f},{b['y'] + b['h'] / 2:.0f})"
            fad = f"\\fad({fin},{fout})"
            lines.append(f"Dialogue: 0,{ass_time(e['start'])},{ass_time(e['end'])},Overlay,,0,0,0,,"
                         f"{{{pos}{base}{fad}}}{text}")
            continue
        obs = e["obs"]
        for i, (a, b) in enumerate(zip(obs, obs[1:] + [{**obs[-1], "t": e["end"]}])):
            ca = (a["x"] + a["w"] / 2, a["y"] + a["h"] / 2)
            cb = (b["x"] + b["w"] / 2, b["y"] + b["h"] / 2)
            dur = int(round((b["t"] - a["t"]) * 1000))
            fad = f"\\fad({fin if i == 0 else 0},{fout if i == len(obs) - 1 else 0})"
            lines.append(f"Dialogue: 0,{ass_time(a['t'])},{ass_time(b['t'])},Overlay,,0,0,0,,"
                         f"{{\\an5\\move({ca[0]:.0f},{ca[1]:.0f},{cb[0]:.0f},{cb[1]:.0f},0,{dur}){base}{fad}}}{text}")
    Path(path).write_text("\n".join([
        "[Script Info]", "ScriptType: v4.00+", f"PlayResX: {W}", f"PlayResY: {H}", "WrapStyle: 2",
        "ScaledBorderAndShadow: yes", "YCbCr Matrix: TV.709", "",
        "[V4+ Styles]",
        "Format: Name, Fontname, Fontsize, PrimaryColour, SecondaryColour, OutlineColour, BackColour, Bold, "
        "Italic, Underline, StrikeOut, ScaleX, ScaleY, Spacing, Angle, BorderStyle, Outline, Shadow, Alignment, "
        "MarginL, MarginR, MarginV, Encoding",
        f"Style: Overlay,{font},60,&H00FFFFFF,&H00FFFFFF,&H00000000,&H00000000,-1,0,0,0,100,100,0,0,1,3,0,5,0,0,0,1",
        "", "[Events]", "Format: Layer, Start, End, Style, Name, MarginL, MarginR, MarginV, Effect, Text",
        *lines, ""]), encoding="utf-8")


# ------------------------------------------------------------------ compositor
_masks = {}


def feather_mask(w, h, feather, hard=(False, False, False, False)):
    """Smooth 0→1 ramp from each edge; sides flagged in `hard` (left, top, right, bottom) stay opaque,
    used where the cover is cut off by the frame border so text there is not left half-visible."""
    key = (w, h, round(feather), hard)
    if key not in _masks:
        big = 10 ** 6
        left = np.arange(w) if not hard[0] else np.full(w, big)
        right = np.arange(w)[::-1] if not hard[2] else np.full(w, big)
        top = np.arange(h) if not hard[1] else np.full(h, big)
        bottom = np.arange(h)[::-1] if not hard[3] else np.full(h, big)
        yy = np.minimum(top, bottom)[:, None]
        xx = np.minimum(left, right)[None, :]
        edge = np.minimum(yy, xx).astype(float)
        a = np.clip(edge / max(1.0, feather), 0, 1)
        _masks[key] = (a * a * (3 - 2 * a))[:, :, None]  # smoothstep
    return _masks[key]


def blur_patch(frame, cx, cy, cw, ch, strength=1.0, feather=None):
    """Feathered Gaussian blur centred at (cx, cy) with size (cw, ch), blended in place."""
    from PIL import Image, ImageFilter
    H, W, _ = frame.shape
    feather = 0.3 * ch if feather is None else feather
    radius = max(4.0, 0.32 * (ch - 2 * feather) if ch > 3 * feather else 0.32 * ch)
    m = int(radius * 2)
    x0, y0 = int(cx - cw / 2), int(cy - ch / 2)
    x1, y1 = int(cx + cw / 2), int(cy + ch / 2)
    X0, Y0, X1, Y1 = max(0, x0 - m), max(0, y0 - m), min(W, x1 + m), min(H, y1 + m)
    if X1 - X0 < 4 or Y1 - Y0 < 4:
        return
    region = frame[Y0:Y1, X0:X1]
    blurred = np.asarray(Image.fromarray(region).filter(ImageFilter.GaussianBlur(radius)), dtype=np.float32) * 0.86
    cx0, cy0 = max(0, x0) - X0, max(0, y0) - Y0
    cx1, cy1 = min(W, x1) - X0, min(H, y1) - Y0
    if cx1 - cx0 < 2 or cy1 - cy0 < 2:
        return
    hard = (x0 <= 0, y0 <= 0, x1 >= W, y1 >= H)
    alpha = feather_mask(cx1 - cx0, cy1 - cy0, feather, hard) * strength
    src = region[cy0:cy1, cx0:cx1].astype(np.float32)
    region[cy0:cy1, cx0:cx1] = (src * (1 - alpha) + blurred[cy0:cy1, cx0:cx1] * alpha).astype(np.uint8)


def _erase(frame, active, t, fps, eraser, stats):
    """Inpaint the glyphs of static captions; returns (frame, captions that still need a blur cover).

    Moving captions and captions whose glyph mask looks implausible (missed text) fall back to blur,
    except at the first/last couple of frames, where the text may simply not be on screen yet.
    """
    from .inpaint import MIN_COVERAGE, glyph_mask
    mask, blur = None, []
    for e in active:
        if e.get("moving"):
            blur.append(e)
            continue
        m, coverage = glyph_mask(frame, e["box"])
        if coverage < MIN_COVERAGE:
            if e["start"] + 2.5 / fps <= t < e["end"] - 2.5 / fps:
                blur.append(e)
                stats["fallback"] = stats.get("fallback", 0) + 1
            continue
        mask = m if mask is None else mask | m
    if mask is not None:
        frame = eraser(frame, mask)
        stats["inpainted"] = stats.get("inpainted", 0) + 1
    return frame, blur


def _composite_chunk(video, shown, workdir, meta, ffmpeg, first, count, crf, preset, eraser=None):
    """Cover + ASS for frames [first, first+count) into workdir/part_<first>.mp4 (video only).

    Returns (path, frames written, stats). An existing part is reused, so an interrupted render resumes.
    """
    fps, W, H = meta["fps"], meta["w"], meta["h"]
    start_t = first / fps
    out = Path(workdir) / f"part_{first:08d}.mp4"
    stats = {}
    if out.exists():
        return str(out), None, stats
    tmp_out = out.with_suffix(".tmp.mp4")
    # Re-base pts so the ASS clock matches the source timeline, then back to zero for concat.
    vf = f"setpts=PTS+{start_t:.6f}/TB,ass=overlay.ass,setpts=PTS-STARTPTS"
    from fractions import Fraction
    rate = str(Fraction(fps).limit_denominator(1001))
    # explicit output rate: ffmpeg >= 7 treats setpts output as variable-rate and drops frames otherwise
    writer = subprocess.Popen(
        [ffmpeg, "-v", "error", "-y", "-f", "rawvideo", "-pix_fmt", "rgb24", "-s", f"{W}x{H}",
         "-framerate", rate, "-i", "-", "-vf", vf, "-r", rate, "-an", "-c:v", "libx264", "-preset", preset,
         "-crf", str(crf), "-pix_fmt", "yuv420p", str(tmp_out)], stdin=subprocess.PIPE, cwd=workdir)
    nxt, active, written = 0, [], 0
    try:
        # seek a quarter frame early: accurate seeking keeps the first frame with pts >= -ss
        frames = _frames(ffmpeg, video, W, H, "rgb24", start=max(0.0, (first - 0.25) / fps) if first else None,
                         count=count)
        for n, frame in enumerate(frames, first):
            t = n / fps
            while nxt < len(shown) and shown[nxt]["start"] <= t:
                if shown[nxt]["end"] > t:
                    active.append(shown[nxt])
                nxt += 1
            active = [e for e in active if e["end"] > t]
            if active:
                frame = frame.copy()
                if eraser is not None:
                    frame, active_blur = _erase(frame, active, t, fps, eraser, stats)
                else:
                    active_blur = active
                for e in active_blur:
                    b = box_at(e, t)
                    L = e["layout"]
                    # full strength from the first frame: source text appears instantly, a ramp would
                    # let it show through; only the drawn translation fades
                    blur_patch(frame, b["x"] + b["w"] / 2, b["y"] + b["h"] / 2, L["cover_w"], L["cover_h"],
                               feather=L.get("feather"))
            writer.stdin.write(frame.tobytes())
            written += 1
    finally:
        writer.stdin.close()
        code = writer.wait()
    if code:
        raise RuntimeError(f"ffmpeg 編碼失敗（exit {code}）")
    tmp_out.replace(out)
    return str(out), written, stats


def composite(video, events, ass_path, out_path, meta, ffmpeg, *, crf=19, preset="veryfast", workers=4,
              log=print, cover="blur", parts_dir=None, device=None, eraser=None, chunk_seconds=60):
    """Chunks → lossless concat → original audio muxed back.

    cover="blur": parallel chunks in separate processes, parts in a temp dir.
    cover="lama": glyph inpainting with one model in this process, chunk by chunk; parts are kept in
    `parts_dir` (when given) so an interrupted multi-hour render resumes. `eraser` overrides the model
    (tests).
    """
    fps = meta["fps"]
    shown = sorted((e for e in events if e.get("translate")), key=lambda e: e["start"])
    total = int(round(meta["duration"] * fps))
    began = time.time()
    src = str(Path(video).resolve())
    with tempfile.TemporaryDirectory() as tmp:
        workdir = Path(parts_dir) if parts_dir else Path(tmp)
        workdir.mkdir(parents=True, exist_ok=True)
        shutil.copy(ass_path, workdir / "overlay.ass")  # filter args cannot hold arbitrary paths safely
        if cover == "blur":
            from concurrent.futures import ProcessPoolExecutor
            workers = max(1, min(workers, total // int(fps * 10) or 1))  # chunks of at least ~10 s
            size = -(-total // workers)
            with ProcessPoolExecutor(max_workers=workers) as pool:
                jobs = [pool.submit(_composite_chunk, src, shown, str(workdir), meta, ffmpeg,
                                    k * size, None if k == workers - 1 else size, crf, preset)
                        for k in range(workers)]
                parts = [job.result()[0] for job in jobs]
            log(f"  🎞️  {workers} 段合成完成（{(time.time() - began) / 60:.1f} 分鐘）")
        elif cover == "lama":
            if eraser is None:
                from .inpaint import Lama
                eraser = Lama(device)
                log(f"  🧽 LaMa 修補（{eraser.device}）")
            size = max(1, int(round(chunk_seconds * fps)))
            n = -(-total // size)
            parts, stats = [], {}
            for k in range(n):
                t0 = time.time()
                part, written, st = _composite_chunk(src, shown, str(workdir), meta, ffmpeg, k * size,
                                                     None if k == n - 1 else size, crf, preset, eraser=eraser)
                parts.append(part)
                for key, v in st.items():
                    stats[key] = stats.get(key, 0) + v
                if written is None:
                    log(f"  ⏭️  {k + 1}/{n} 已完成（沿用）")
                else:
                    log(f"  🧽 {k + 1}/{n}：{st.get('inpainted', 0)} 格修補（{time.time() - t0:.0f}s）")
            log(f"  🎞️  {n} 段合成完成（{(time.time() - began) / 60:.1f} 分鐘）；"
                f"遮罩不可靠改用模糊 {stats.get('fallback', 0)} 次")
        else:
            raise ValueError(f"unknown cover mode: {cover}")
        listing = workdir / "parts.txt"
        listing.write_text("".join(f"file '{Path(p).resolve()}'\n" for p in parts))
        subprocess.run([ffmpeg, "-v", "error", "-y", "-f", "concat", "-safe", "0", "-i", str(listing),
                        "-i", src, "-map", "0:v", "-map", "1:a?", "-c", "copy",
                        str(Path(out_path).resolve())], check=True)  # no -shortest: it drops a final frame at random
    return out_path
