"""Subtitle processing without a dependency on any consumer repository."""
from .types import Segment, SegmentEvent
from .pipeline import ASRSelection, TextSelection, PipelineConfig, Pipeline

__version__ = "0.3.1"
__all__ = ["Segment", "SegmentEvent", "ASRSelection", "TextSelection", "PipelineConfig", "Pipeline"]
