"""Shared libass styling for dialogue burn-in (never modifies subtitle text)."""


def validate_background(background, opacity):
    if type(background) is not str or background not in ("none", "box"):
        raise ValueError("subtitle_background must be none or box")
    if type(opacity) is not int or not 0 <= opacity <= 100:
        raise ValueError("subtitle_background_opacity must be an integer between 0 and 100")


def subtitle_filter(background="none", opacity=80):
    """Caller copies SRT to subtitle.srt and uses its directory as FFmpeg cwd.

    libass 0.15.2: BorderStyle=3 fits each line separately; style 4 fills the
    entire event's bounding rectangle, including empty space beside short lines.
    Outline=4 gives roughly half a visible glyph height of inset for the
    default SRT font (about 12–17 px padding around 26 px glyphs at 720p).
    ASS alpha is transparency (00 opaque, FF transparent), unlike our opacity.
    """
    validate_background(background, opacity)
    if background == "none":
        return "subtitles=subtitle.srt"
    alpha = round(255 * (100 - opacity) / 100)
    colour = f"&H{alpha:02X}000000"
    return ("subtitles=subtitle.srt:force_style='BorderStyle=3,PrimaryColour=&H00FFFFFF,"
            f"OutlineColour={colour},BackColour={colour},Outline=4,Shadow=0'")
