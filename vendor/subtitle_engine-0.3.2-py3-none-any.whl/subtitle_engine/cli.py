"""Interactive offline CLI adapter."""
from .processor import *

def main():
    # 載入 .env 環境變數（CLI 參數優先，不覆寫已有的 env）
    load_dotenv(dotenv_path=Path.cwd() / ".env")

    parser = argparse.ArgumentParser(
        description="自動化影片字幕處理工具 - 支援 YouTube 下載、Whisper 轉錄、AI 校正/翻譯、FFmpeg 嵌入字幕",
        formatter_class=argparse.RawDescriptionHelpFormatter,
        epilog="""
使用範例:
  # 完整流程：處理 YouTube 影片（API key 從 .env 讀取）
  python subtitle_refine.py --youtube "https://www.youtube.com/watch?v=xxxxx"

  # 完整流程：處理本地英文影片並翻譯成繁體中文
  python subtitle_refine.py --video "./video.mp4" --api-key "GEMINI_KEY" --source-lang en --translate zh-TW

  # 使用 OpenAI 處理
  python subtitle_refine.py --video "./video.mp4" --provider openai --openai-api-key "sk-..." --translate zh-TW

  # 使用音訊上下文進行多模態處理（僅支援 Gemini）
  python subtitle_refine.py --video "./video.mp4" --use-audio-context --translate zh-TW

  # 跳過下載和轉錄：僅校正/翻譯現有字幕並嵌入影片
  python subtitle_refine.py --video "./video.mp4" --subtitle "./video.srt" --translate en

  # 純字幕嵌入：直接將已處理好的字幕嵌入影片（不使用 AI）
  python subtitle_refine.py --video "./video.mp4" --subtitle "./video_translated.srt" --only-embed

  # 使用自定義 Gemini 模型
  python subtitle_refine.py --video "./video.mp4" --gemini-model "gemini-2.5-pro"

  # 使用自定義 OpenAI 模型
  python subtitle_refine.py --video "./video.mp4" --provider openai --openai-model "gpt-4o-mini"

環境變數（可寫入 .env 檔案，避免每次傳入 API key）:
  GEMINI_API_KEY=your_gemini_api_key
  OPENAI_API_KEY=your_openai_api_key

支援的語言代碼:
  zh/zh-TW (繁體中文), zh-CN (簡體中文), en (英文), ja (日文), ko (韓文)
  es (西班牙文), fr (法文), de (德文), it (義大利文), pt (葡萄牙文)
  ru (俄文), ar (阿拉伯文), th (泰文), vi (越南文), auto (自動偵測)

可用的 Gemini 模型:
  gemini-2.5-flash (推薦，性價比最高)
  gemini-2.5-flash-lite (最快，成本最低)
  gemini-2.5-pro (最強大，思考能力最好)
  gemini-2.0-flash (第二代，長上下文)

可用的 OpenAI 模型:
  gpt-4o (推薦，性價比最高)
  gpt-4o-mini (最快，成本最低)
  gpt-4.1 (最新旗艦)
  o3 / o4-mini (推理模型)
        """
    )

    # 輸入來源
    input_group = parser.add_mutually_exclusive_group(required=True)
    input_group.add_argument("--youtube", "-y", help="YouTube 影片網址")
    input_group.add_argument("--video", "-v", help="本地影片檔案路徑")

    # AI Provider 設定
    parser.add_argument(
        "--provider",
        choices=["gemini", "openai", "local-runtime"],
        default="gemini",
        help="AI 提供商 (預設: gemini)"
    )

    # Gemini API 設定
    parser.add_argument("--api-key", "-k", help="Gemini API 金鑰（也可設定環境變數 GEMINI_API_KEY）")
    parser.add_argument(
        "--gemini-model", "-gm",
        default="gemini-2.5-flash",
        help="Gemini 模型名稱 (預設: gemini-2.5-flash)"
    )

    # OpenAI API 設定
    parser.add_argument("--openai-api-key", "-oak", help="OpenAI API 金鑰（也可設定環境變數 OPENAI_API_KEY）")
    parser.add_argument(
        "--openai-model", "-om",
        default=None,
        help="模型名稱；OpenAI 預設 gpt-4o，runtime 使用 connection.json 的模型"
    )

    parser.add_argument("--openai-base-url", help="OpenAI-compatible Base URL（含 /v1）")
    parser.add_argument("--runtime-config", help="local-runtime 的 connection.json 路徑")
    parser.add_argument("--max-workers", type=int, default=4, help="最大並行請求數（預設 4）")

    # 語言設定
    parser.add_argument(
        "--source-lang", "-sl",
        default="zh",
        help="影片的原始語言 (預設: zh 中文，可用 auto 自動偵測)"
    )

    parser.add_argument(
        "--translate", "-t",
        help="翻譯成目標語言 (例如: en, ja, ko, zh-TW 等)"
    )

    # Whisper 設定
    parser.add_argument(
        "--whisper-model", "-w",
        default="base",
        choices=["tiny", "base", "small", "medium", "large"],
        help="Whisper 模型大小 (預設: base)"
    )

    # AI 校正設定
    parser.add_argument("--prompt", "-p", help="自定義 AI 校正提示詞")
    parser.add_argument("--context", "-c", help="額外的上下文資訊")
    parser.add_argument("--skip-correction", "-s", action="store_true", help="跳過 AI 字幕校正")
    parser.add_argument(
        "--use-audio-context", "-uac",
        action="store_true",
        help="使用音訊上下文進行多模態處理（僅支援 Gemini，會同時分析音訊和字幕，提供更準確的校正）"
    )

    # 跳過步驟的選項
    parser.add_argument(
        "--subtitle", "-sub",
        help="現有字幕檔案路徑（提供此選項將跳過下載和轉錄步驟）"
    )

    parser.add_argument(
        "--only-embed", "-oe",
        action="store_true",
        help="僅執行字幕嵌入（需要同時提供 --video 和 --subtitle，跳過所有其他步驟包括 AI 校正）"
    )

    parser.add_argument("--subtitle-background", choices=["none", "box"], default="none", help="燒錄字幕底色（預設 none）")
    parser.add_argument("--subtitle-background-opacity", type=int, choices=range(101), default=80,
                        metavar="0..100", help="字幕底色不透明度百分比（預設 80）")
    args = parser.parse_args()

    # 解析 effective API keys（CLI 參數 > 環境變數）
    effective_gemini_key = args.api_key or os.environ.get("GEMINI_API_KEY")
    effective_openai_key = args.openai_api_key or os.environ.get("OPENAI_API_KEY")

    if args.max_workers < 1:
        parser.error("--max-workers 必須大於 0")
    base_url = args.openai_base_url or os.environ.get("OPENAI_BASE_URL")
    model = args.openai_model or "gpt-4o"
    if args.provider == "local-runtime" and not args.only_embed and (not args.skip_correction or args.translate):
        root = (Path(os.environ.get("LOCALAPPDATA", "~")).expanduser() / "Personal AI Runtime"
                if sys.platform == "win32" else Path.home() / "Library/Application Support/personal-ai-runtime")
        config_path = Path(args.runtime_config).expanduser() if args.runtime_config else root / "connection.json"
        try:
            config = json.loads(config_path.read_text(encoding="utf-8"))
            # Runtime 金鑰與官方 OpenAI 金鑰分開，避免誤送憑證。
            effective_openai_key = config["api_key"]
            base_url = config["base_url"]
            model = args.openai_model or config.get("model", "gpt-6-luna")
            from urllib.parse import urlparse
            parsed = urlparse(base_url)
            if parsed.scheme != "http" or parsed.hostname not in ("127.0.0.1", "localhost", "::1"):
                raise ValueError("Runtime Base URL 必須是本機 HTTP 位址")
        except (OSError, ValueError, KeyError, TypeError):
            parser.error("無法讀取有效的本機 runtime connection.json；請先安裝 runtime 或指定 --runtime-config")

    # 檢查 only-embed 模式的必要參數
    if args.only_embed:
        if not args.video or not args.subtitle:
            parser.error("--only-embed mode requires both --video and --subtitle")
        if args.youtube:
            parser.error("--only-embed mode cannot be used with --youtube")

    # 檢查 use-audio-context 的參數衝突
    if args.use_audio_context:
        if args.only_embed:
            parser.error("--use-audio-context cannot be used with --only-embed (no AI processing in only-embed mode)")
        if args.skip_correction:
            parser.error("--use-audio-context cannot be used with --skip-correction (audio context is only used for AI correction)")
        if args.provider in ("openai", "local-runtime"):
            parser.error("--use-audio-context 僅支援 Gemini，請移除 --provider openai 或移除 --use-audio-context")

    # 檢查 API key（僅在需要 AI 處理時）
    # 注意：對於 YouTube 來源，可能會使用 CC 字幕並在互動選擇中跳過 AI，所以延後檢查
    if not args.only_embed and (not args.skip_correction or args.translate):
        if args.provider in ("openai", "local-runtime"):
            if not effective_openai_key and not args.youtube:
                parser.error("使用 OpenAI 時需要 --openai-api-key 或在 .env 中設定 OPENAI_API_KEY")
        else:
            if not effective_gemini_key and not args.youtube:
                parser.error("使用 Gemini 時需要 --api-key 或在 .env 中設定 GEMINI_API_KEY")

    # 檢查必要工具
    missing_tools = []

    # 檢查並初始化 ffmpeg
    print("🔍 檢查 FFmpeg...")
    ffmpeg_path = get_ffmpeg_path()

    try:
        result = subprocess.run([ffmpeg_path, "-version"], capture_output=True, check=True, timeout=5)
        print(f"✅ FFmpeg 已就緒: {ffmpeg_path}")
    except (subprocess.CalledProcessError, FileNotFoundError, subprocess.TimeoutExpired) as e:
        print(f"❌ FFmpeg 檢查失敗: {e}")
        missing_tools.append("ffmpeg")

    # 檢查 yt-dlp（僅在需要下載 YouTube 影片時）
    if args.youtube and not args.only_embed:
        try:
            subprocess.run(["yt-dlp", "--version"], capture_output=True, check=True, timeout=5)
        except (subprocess.CalledProcessError, FileNotFoundError, subprocess.TimeoutExpired):
            missing_tools.append("yt-dlp")

    # 檢查 whisper（僅在需要轉錄時）
    if not args.subtitle and not args.only_embed:
        try:
            import whisper
        except ImportError:
            missing_tools.append("whisper")

    if missing_tools:
        print("❌ 缺少必要工具，請先安裝:")
        for tool in missing_tools:
            if tool == "yt-dlp":
                print(f"  pip install yt-dlp")
            elif tool == "whisper":
                print(f"  pip install openai-whisper")
            elif tool == "ffmpeg":
                print(f"  pip install static-ffmpeg")
                print(f"  # 或者手動安裝: brew install ffmpeg (macOS)")
        sys.exit(1)

    # 初始化處理器
    processor = VideoSubtitleProcessor(
        gemini_api_key=effective_gemini_key,
        whisper_model=args.whisper_model,
        source_language=args.source_lang,
        gemini_model=args.gemini_model,
        provider=args.provider,
        openai_api_key=effective_openai_key,
        openai_model=model,
        openai_base_url=base_url,
        max_workers=args.max_workers
    )

    # 開始處理
    try:
        input_source = args.youtube if args.youtube else args.video
        is_youtube = args.youtube is not None

        processor.process(
            input_source=input_source,
            is_youtube=is_youtube,
            custom_prompt=args.prompt,
            context=args.context,
            skip_correction=args.skip_correction,
            target_language=args.translate,
            existing_subtitle=args.subtitle,
            skip_download=args.subtitle is not None and not is_youtube,
            skip_transcribe=args.subtitle is not None,
            only_embed=args.only_embed,
            use_audio_context=args.use_audio_context,
            subtitle_background=args.subtitle_background,
            subtitle_background_opacity=args.subtitle_background_opacity
        )

    except Exception as e:
        print(f"\n❌ 處理失敗: {e}")
        import traceback
        traceback.print_exc()
        sys.exit(1)


if __name__ == "__main__":
    main()
